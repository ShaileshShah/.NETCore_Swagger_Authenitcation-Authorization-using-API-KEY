﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Shouldly;
using Xunit;

namespace Swagger_Operation.Tests
{
    public class AuthorizationIntegrationTests : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> _factory;

        public AuthorizationIntegrationTests(WebApplicationFactory<Startup> factory)
        {
            _factory = factory ?? throw new ArgumentNullException(nameof(factory));
        }

        [Fact]
        public async Task GivenAuthorizedCall_WhenGetOnlyThirdParties_ThenReturns200Ok()
        {
            var httpClient = _factory.CreateClient();
            var request = new HttpRequestMessage(HttpMethod.Get, "api/Values/onlyemployees");
            var apiKey = "C5BFF7F0-B4DF-475E-A331-F737424F013C1"; 
            request.Headers.Add("X-Api-Key", apiKey);

            var response = await httpClient.SendAsync(request);

            response.StatusCode.ShouldBe(HttpStatusCode.OK);
        }
    }
}
