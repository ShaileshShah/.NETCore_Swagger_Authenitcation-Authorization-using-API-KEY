﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JOS.ApiKeyAuthentication.Web.Features.Authorization;

namespace JOS.ApiKeyAuthentication.Web.Features.Authentication
{
    public class InMemoryGetAllApiKeysQuery : IGetAllApiKeysQuery
    {
        public Task<IReadOnlyDictionary<string, ApiKey>> ExecuteAsync()
        {
            var apiKeys = new List<ApiKey>
            {
                new ApiKey(1, "Finance", "C5BFF7F0-B4DF-475E-A331-F737424F013C1", new DateTime(2019, 01, 01),
                    new List<string>
                    {
                        Roles.Employee,
                    }),
                new ApiKey(2, "Reception", "C5BFF7F0-B4DF-475E-A331-F737424F013C2", new DateTime(2019, 01, 01),
                    new List<string>
                    {
                        Roles.Employee
                    }),
                new ApiKey(3, "Management", "C5BFF7F0-B4DF-475E-A331-F737424F013C3", new DateTime(2019, 01, 01),
                    new List<string>
                    {
                        Roles.Employee,
                        Roles.Manager
                    }),
                new ApiKey(4, "Some Third Party", "C5BFF7F0-B4DF-475E-A331-F737424F013C4", new DateTime(2019, 06, 01),
                    new List<string>
                    {
                        Roles.ThirdParty
                    })
            };

            IReadOnlyDictionary<string, ApiKey> readonlyDictionary = apiKeys.ToDictionary(x => x.Key, x => x);
            return Task.FromResult(readonlyDictionary);
        }
    }
}
